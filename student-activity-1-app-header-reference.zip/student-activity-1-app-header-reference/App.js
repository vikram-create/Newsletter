import * as React from 'react';
import { View } from 'react-native';
import SoundButton from './components/SoundButton'
import AppHeader from './components/AppHeader'
import Button2 from './components/Button2'
import Button3 from './components/Button3'
import Like from './components/LikeButton'
import Dislike from './components/DislikeButton'

export default class App extends React.Component {
  render() {
    return (
      <View>
        <AppHeader/>
        <SoundButton />
        <Button2 />
        <Button3 />
        <Like />
        <Dislike />
      </View>
    );
  }
}

